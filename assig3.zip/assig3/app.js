const express = require('express');
const post = require('../assig3/post')
const app = express();

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.render('index',{post});
});

app.get('/new', (req, res) => {
  res.render('new');
});

app.post('/', async (req, res) => {
  const post = {title: req.body.title, content: req.body.content}
  post.push(post);
  res.redirect("/");
});

app.listen(4000, () => {
  console.log('Server is listening on port 4000');
});
